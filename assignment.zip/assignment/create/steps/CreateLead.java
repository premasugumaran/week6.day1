package steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateLead extends BaseClass{
	//public ChromeDriver driver;
	
//	@Given("Launch the browser")
//	public void launchBrowser() {
//		WebDriverManager.chromedriver().setup();
//		driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
//	}
//	
//	@Given("Load the Url")
//	public void loadUrl() {
//		driver.get("http://leaftaps.com/opentaps/");
//	}
//	
	@Given("Enter username as {string}")
	public void enterUsername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
	}
	
	@Given("Enter password as {string}")
	public void enterPassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	
	@When("Click on login button")
	public void login() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}
	
	@Then("Homepage should be displayed")
	public void homepage() {
		String title = driver.getTitle();
		System.out.println(title);
		
	}
	@Given ("click CRMSFA")
	public void crmsfa() {
		driver.findElement(By.linkText("CRM/SFA")).click();
	}
	
	@Given("click on leads button")
	public void leadButton() {
		driver.findElement(By.linkText("Leads")).click();
		
	}
	
	@Given("click on create lead button")
	public void createLead() {
		driver.findElement(By.linkText("Create Lead")).click();
	}
	
	@Given("Enter company name as {string}")
	public void enterCompanyname(String company) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(company);
	}
	
	@Given("Enter first name as {string}")
	public void enterFirstname(String fname) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
	}
	
	@Given("Enter last name as {string}")
	public void enterLastname(String lname) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
	}
	
	@When("Click on submit button")
	public void clickSubmit() {
		driver.findElement(By.name("submitButton")).click();
	}
	
	@Then("Create page displayed")
	public void leadPage() {
		String title1 = driver.getTitle();
		System.out.println(title1);
		
		
	}

}
