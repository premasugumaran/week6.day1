package mergeSteps;

import org.openqa.selenium.chrome.ChromeDriver;

public class MergeBaseClass {
	public static ChromeDriver driver;
}
