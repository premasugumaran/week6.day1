package editcreateSteps;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class EditSteps extends EditBaseClass {
	
	@Given ("Enter username as {string}")
	public void enterUsername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
	}	
	@And ("Enter password as {string}")
	public void enterPassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	@When ("Click on login button")
	public void login() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}
	@Then ("Homepage should be displayed")
	public void homepage() {
		String title = driver.getTitle();
		System.out.println(title);
		
	}
	@Given ("click CRMSFA")
	public void crmsfa() {
		driver.findElement(By.linkText("CRM/SFA")).click();
	}
	@And ("click on leads button")
	public void leadButton() {
		driver.findElement(By.linkText("Leads")).click();
		
	}
	@And ("click on Findbutton")
	public void findButton() {
		driver.findElement(By.linkText("Find Leads")).click();

	}
	@And ("Enter first name as {string}")
	public void firstname(String name) {
		driver.findElement(By.xpath("(//input[@name='firstName'])[3]")).sendKeys(name);

	}
	@When ("click on Findlead button")
	public void findLead() {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();

	}
	@Then ("EditLead should be displayed")
	public void edit() throws InterruptedException {
		//driver.findElement(By.xpath("//td[@class='x-grid3-col x-grid3-cell x-grid3-td-partyId x-grid3-cell-first ']//a")).click();
		
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a")).click();
		//driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		String title = driver.getTitle();
		System.out.println(title);
		driver.findElement(By.xpath("//a[text()='Edit']")).click();

	}
	@Given ("Enter company name as {string}")
	public void company(String company) {
		WebElement comp=driver.findElement(By.id("updateLeadForm_companyName"));
		String companyname=comp.getAttribute("value");
		comp.clear();
		comp.sendKeys(company,Keys.TAB);
		
	}
	@When ("Click on submit button")
	public void submit() {
		driver.findElement(By.xpath("(//input[@class='smallSubmit'])[1]")).click();

	}

	@Then ("Lead should be updated")
	public void leadPage() {
		String title=driver.getTitle();
		System.out.println(title);
	}


}
