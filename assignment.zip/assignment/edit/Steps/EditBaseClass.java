package editcreateSteps;

import org.openqa.selenium.chrome.ChromeDriver;

public class EditBaseClass {
	public static ChromeDriver driver;

}
