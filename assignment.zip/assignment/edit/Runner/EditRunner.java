package editCreateRunner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.CucumberOptions.SnippetType;
@CucumberOptions(features="src/test/java/editLeadFeatures/EditFeature.feature"
		,glue="editcreateSteps"
		,monochrome = true
		,dryRun=false
		,snippets = SnippetType.CAMELCASE

		)
public class EditRunner extends AbstractTestNGCucumberTests{

}
