package deleteRunner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.CucumberOptions.SnippetType;


	@CucumberOptions(features="src/test/java/deleteFeatures"
			,glue="deleteSteps"
			,monochrome = true
			,dryRun=false
			,snippets = SnippetType.CAMELCASE
			)
	public class DeleteRunner extends AbstractTestNGCucumberTests {
		
}
