package deleteSteps;

import org.openqa.selenium.chrome.ChromeDriver;

public class DeleteBaseClass {
	public static ChromeDriver driver;
}
