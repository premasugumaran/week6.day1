package deleteSteps;

import org.openqa.selenium.By;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DeleteSteps extends DeleteBaseClass{
	@Given ("Enter username as Demosalesmanager")
	public void enterUsername() {
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
	}	
	@And ("Enter password as crmsfa")
	public void enterPassword() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
	}
	@When ("Click on login button")
	public void login() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}
	@Then ("Homepage should be displayed")
	public void homepage() {
		String title = driver.getTitle();
		System.out.println(title);
		
	}
	@Given ("click CRMSFA")
	public void crmsfa() {
		driver.findElement(By.linkText("CRM/SFA")).click();
	}
	@And ("click on leads button")
	public void leadButton() {
		driver.findElement(By.linkText("Leads")).click();
		
	}
	@And ("click on find lead button")
	public void findLead() {
		driver.findElement(By.linkText("Find Leads")).click();

	}
	@And ("click phonenumber tab")
	public void phoneTab() {
		driver.findElement(By.xpath("//span[text()='Phone']")).click();

	}
	@And ("Enter phonenumber")
	public void enterPhone() {
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys("80");
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
	}
	@When ("Click on first ID")
	public void firstID() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();

		
	}
	@Then ("delete the lead")
	public void deleteLead() {
		driver.findElement(By.linkText("Delete")).click();

	}

}
