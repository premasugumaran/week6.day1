package duplicateSteps;

import org.openqa.selenium.By;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DuplicateSteps extends DuplicateBase {
	@Given ("Enter username as {string}")
	public void enterUsername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
	}	
	@And ("Enter password as {string}")
	public void enterPassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	@When ("Click on login button")
	public void login() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}
	@Then ("Homepage should be displayed")
	public void homepage() {
		String title = driver.getTitle();
		System.out.println(title);
		
	}
	@Given ("click CRMSFA")
	public void crmsfa() {
		driver.findElement(By.linkText("CRM/SFA")).click();
	}
	@And ("click on leads button")
	public void leadButton() {
		driver.findElement(By.linkText("Leads")).click();
		
	}
	@And ("click on Findbutton")
	public void findButton() {
		driver.findElement(By.linkText("Find Leads")).click();

	}
	@And ("click on email button")
	public void emailbutton() {
		driver.findElement(By.xpath("//span[text()='Email']")).click();
		
	}
	@And ("Enter email id as {string}")
	public void email(String email) {
		driver.findElement(By.xpath("//input[@name='emailAddress']")).sendKeys(email);

	}
	@When ("click on Findlead button")
	public void findLead() {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();

	}
	@Then ("get the first displayed name")
	public void selectfirst() throws InterruptedException {
		Thread.sleep(3000);
		 String FirstName= driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-firstName']")).getText();
		System.out.println(FirstName);
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();

	}
	@When ("Click on duplicate button")
	public void duplicateButton() {
		driver.findElement(By.linkText("Duplicate Lead")).click(); 

	}
	@And ("click on submit button")
	public void submit() {
		driver.findElement(By.className("smallSubmit")).click();

	}
	@Then ("verify the duplicated lead")
	public void verify() {
		String DuplicateName = driver.findElement(By.xpath("//span[@id='viewLead_firstName_sp']")).getText();
		System.out.println(DuplicateName);
		String title = driver.getTitle();
		System.out.println(title);

	}

}
