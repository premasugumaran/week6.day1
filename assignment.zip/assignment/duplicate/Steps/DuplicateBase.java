package duplicateSteps;

import org.openqa.selenium.chrome.ChromeDriver;

public class DuplicateBase {
	public static ChromeDriver driver;


}
