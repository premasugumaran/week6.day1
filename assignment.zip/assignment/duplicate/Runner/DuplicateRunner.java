package duplicateRunner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.CucumberOptions.SnippetType;

@CucumberOptions(features="src/test/java/duplicatefeatures/duplicate.feature"
,glue="duplicateSteps"
,monochrome = true
,dryRun=false
,snippets = SnippetType.CAMELCASE

)
public class DuplicateRunner extends AbstractTestNGCucumberTests{

}
